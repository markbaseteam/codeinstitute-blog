
> [!NOTE] Title
> ## Creating our Heroku app
> 


> [!CITE] WHAT IS IT?
> Contents

> [!CITE] WHAT DOES IT DO?
> Contents

> [!CITE] HOW DO YOU USE IT?
> Contents



> [!ABSTRACT] Abstract
> Contents
> 


> [!COMMAND] Command
> Contents


# FST I Think Therefore I Blog | Walkthrough Deployment : Heroku app

Create a new app on Heroku.

---

In the previous video, we got our skeleton project up and running locally. Now, we want to prepare it for deployment to Heroku. We’re into the third step of our “new project checklist” which is setting the project up to use Cloudinary and an external database.

To do this we need to create the app on Heroku, provision a database, configure some environment variables, and modify the settings of the project to get all this working. It’s important to follow a process when doing this, as deployment issues can cause a lot of frustration, so taking your time and checking off every aspect as you go is strongly advised.

## Process[](https://code-institute-students.github.io/deployment-docs/61-django-blog-walkthrough/django-blog-walkthrough-01-create-heroku-app#process)

Log into Heroku (you should already have an account from previous projects) and go to the Dashboard.

1. Click “**New**”
    
    ![a button with new and an expansion icon](https://code-institute-students.github.io/deployment-docs/assets/heroku/new-button.png)
    
2. Click “**Create new app**”
    
    ![a drop down menu with an option to create a new app](https://code-institute-students.github.io/deployment-docs/assets/heroku/create-new-app.png)
    
3. Give your app a name and select the region closest to you. When you’re done, click “**Create app**” to confirm.
    
    ![an app name text input, a drop down to choose a region and a create app button](https://code-institute-students.github.io/deployment-docs/assets/heroku/naming-app.png)
    

Heroku app names must be unique. If yours isn't, Heroku will give you a warning that looks like the image below.

![red text with a warning to indicate the name chose is taken](https://code-institute-students.github.io/deployment-docs/assets/heroku/name-unavailable.png)

## Up Next[](https://code-institute-students.github.io/deployment-docs/61-django-blog-walkthrough/django-blog-walkthrough-01-create-heroku-app#up-next)

The database provided by Django is only accessible within your IDE and is not suitable for a production environment. The steps to create a new database are on the next page.

***
> . 
***

