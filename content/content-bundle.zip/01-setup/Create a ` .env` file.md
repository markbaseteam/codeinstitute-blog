

> [!NOTE] ## Create .env.py
> - 


> [!CITE] WHAT IS IT?
> 	Environmental Variables

> [!CITE] WHAT DOES IT DO?
> Contains secrets, credentials and sensitive configuration data

> [!CITE] HOW DO YOU USE IT?
> Hiding them by including them in systematic Environmental Variables and .gitinore inclusions

***

> [!ABSTRACT] Abstract: Keeping Things a Secret
> -  variety of variables that you don’t want to publish in your repository.
> - may get an email from GitHub warning you about an exposed secret.
>  - works properly when deployed, we need a way to provide these variables without exposing them to the public 
> 

**`Add OS Package`**
> [!COMMAND] Command
>  ```python
>  import os
>  os.environ["DATABASE_URL"]="copiedURL" 

**`Add Django Secret Key`**
> [!COMMAND] Command
> ```python
> import os
> os.environ["SECRET_KEY"]="my_super^secret@key"

***

# FST I Think Therefore I Blog | Walkthrough Deployment : Create an env.py file

Keeping things secret.

---

There are a variety of variables that you don’t want to publish in your repository. In fact if you do, you may get an email from GitHub warning you about an exposed secret. To ensure your application works properly when deployed, we need a way to provide these variables without exposing them to the public. Luckily, Git and Heroku both have a way to do this.

## Process[](https://code-institute-students.github.io/deployment-docs/61-django-blog-walkthrough/django-blog-walkthrough-03-envpy#process)

1. In your project workspace, create a file called **env.py**. It’s a good idea to check that this file is included in the **.gitignore** file too. If you are using the Code Institute provided GitHub template, then the env.py file is already in the .gitignore file.
    
    ![a gitignore file with a line reading env.py](https://code-institute-students.github.io/deployment-docs/assets/gitpod/gitignore.png)
    
2. In your **env.py** file add the following line of code.
    
    ```
     import os
    ```

1. Next we need to set some **environment variables**. First, add a blank line, then set a **DATABASE_URL** variable, with the value you just copied from ElephantSQL as follows
    
```python
 os.environ["DATABASE_URL"]="copiedURL"
```
    
    Replace `copiedURL` with the relevant string from ElephantSQL.
    
4. As this is a Django application it has a **SECRET_KEY**, which it uses to encrypt session cookies. The secret key can be whatever you like.
    
    We need to include this string in the **env.py** file. So, just like before, add the variable by pasting in the string as follows
    
    ```
     os.environ["SECRET_KEY"]="my_super^secret@key"
    ```
    
    We don't want to share our secrets either, so this documentation shows you a made up key. Just replace `my_super^secret@key` with your key.
    
5. Make sure you **save** the file.
    

## Up Next[](https://code-institute-students.github.io/deployment-docs/61-django-blog-walkthrough/django-blog-walkthrough-03-envpy#up-next)

This secret file isn’t much good on its own. Carry on to edit your settings.py file on the next page, including connecting up your workspace to the new database.

***
> . 
***

