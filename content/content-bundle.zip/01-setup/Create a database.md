
> [!NOTE] Title
> Contents


> [!CITE] WHAT IS IT?
> Contents

> [!CITE] WHAT DOES IT DO?
> Contents

> [!CITE] HOW DO YOU USE IT?
> Contents



> [!ABSTRACT] Abstract
> Contents
> 


> [!COMMAND] Command
> Contents


# FST I Think Therefore I Blog | Walkthrough Deployment : Create a database

These steps will create a new PostgreSQL database instance for use with your project.

---

The database provided by Django is only accessible within your IDE and is not suitable for a production environment. Your deployed project on Heroku will not be able to access it. So, you need to create a new database that can be accessed by Heroku.

If you don't have an ElephantSQL.com account yet, the [steps to create one are here](https://code-institute-students.github.io/deployment-docs/02-elephantsql/elephantsql-01-sign-up).

## Process[](https://code-institute-students.github.io/deployment-docs/61-django-blog-walkthrough/django-blog-walkthrough-02-create-a-database#process)

1. **Log in** to [ElephantSQL.com](https://www.elephantsql.com/) to access your dashboard
    
    ![elephant s q l dashboard](https://code-institute-students.github.io/deployment-docs/assets/elephant/created.png)
    
2. Click “**Create New Instance**”
    
    ![create new instance button](https://code-institute-students.github.io/deployment-docs/assets/elephant/create-new-instance.png)
    
3. Set up your plan
    
    - Give your plan a **Name** (this is commonly the name of the project)
    - Select the **Tiny Turtle (Free)** plan
    - You can leave the **Tags** field blank
        
        ![plan details input boxes](https://code-institute-students.github.io/deployment-docs/assets/elephant/plan-details.png)
        
4. Select “**Select Region**”
    
    ![data center selection](https://code-institute-students.github.io/deployment-docs/assets/elephant/region-button.png)
    
5. Select a data center near you
    
    ![data center selection](https://code-institute-students.github.io/deployment-docs/assets/elephant/data-center-selection.png)
    
    If you receive a message saying "Error: No cluster available in **your-chosen-data-center** yet", choose another region. **Note:** You're free to use any of the available free data centers, be it AWS, Azure or any of the other providers.
    
6. Then click “**Review**”
    
    ![review button](https://code-institute-students.github.io/deployment-docs/assets/elephant/review-button.png)
    
7. Check your details are correct and then click “**Create instance**”
    
    ![details of a database instance with a create instance button](https://code-institute-students.github.io/deployment-docs/assets/elephant/confirm-details-create-instance.png)
    
8. Return to the ElephantSQL dashboard and click on the **database instance name** for this project
    
    ![dashboard populated with instances](https://code-institute-students.github.io/deployment-docs/assets/elephant/populated-dashboard.png)
    
9. In the URL section, click the copy icon to copy the database URL
    
    ![a database url with a copy icon next to it](https://code-institute-students.github.io/deployment-docs/assets/elephant/copy-url-icon.png)
    

## Up Next[](https://code-institute-students.github.io/deployment-docs/61-django-blog-walkthrough/django-blog-walkthrough-02-create-a-database#up-next)

That’s the database created, but what about your existing content? And how does your project interact with this new database? We explore that, and more, in the next few pages.****

***
> . 
***

