
> [!NOTE] Title
> Contents

![](https://youtu.be/gh6eLhf15TM)



> [!ABSTRACT] Abstract
> Contents
> ![](Pasted%20image%2020230721132859.png)


> [!CITE] WHAT IS IT?
> Getting our project set up

> [!CITE] WHAT DOES IT DO?
> Creates a new Django project and app

> [!CITE] HOW DO YOU USE IT?
> Using the Django Admin tools


> [!COMMAND] Command
> Contents



