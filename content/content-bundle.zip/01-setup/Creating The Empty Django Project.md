
> [!NOTE] Title
> Contents


> [!CITE] WHAT IS IT?
> Getting our project set up

> [!CITE] WHAT DOES IT DO?
> Creates a new Django project and app

> [!CITE] HOW DO YOU USE IT?
> Using the Django Admin tools

![](https://youtu.be/MagEuw9Q4T4)

> [!ABSTRACT] Abstract
> WHAT IS IT?
> Getting our project set up
> WHAT DOES IT DO?
> Creates a new Django project and app
> HOW DO YOU USE IT?
> Using the Django Admin tools
> 


> [!COMMAND] Command
> ```bash
>1.  pip3 install django gunicorn
>   
> 2. pip3 install 'django<4' gunicorn  
> 
> 3. pip3 install dj_database_url==0.5.0 psycopg2
> ```




## Terminal command update

Since this video was created Django have introduced a new version that will be automatically installed if you use the command in the video.

To ensure that you get the same version of django and gunicorn used in this video and so that nothing breaks as you do the walkthrough, instead of the command `pip3 install django gunicorn`, please use this:

`pip3 install 'django<4' gunicorn`

As well as this, instead of the 2nd command, pip3 install dj_database_url psycopg2, please use this:

`pip3 install dj_database_url==0.5.0 psycopg2`

Django 3.2 is the LTS (Long Term Support) version of Django and is therefore preferable to use over the newest Django 4

## Viewing your new Django App

At the end of the video, Chris runs the app. Depending on the computer you are running on, you may have to allow a host for the app.

![](https://codeinstitute.s3.eu-west-1.amazonaws.com/codeanywhere/disallowedhost.jpeg)

The error states your specific host. Copy and paste it into the settings.py file ALLOWED_HOSTS.

![Django allowed hosts list in settings.py](https://codeinstitute.s3.eu-west-1.amazonaws.com/codeanywhere/allowed_hosts.jpeg)


***
> . 
***

