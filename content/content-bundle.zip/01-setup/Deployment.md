
> [!NOTE] # First Deployment
> Contents


> [!CITE] WHAT IS IT?
> Our first deployment

> [!CITE] WHAT DOES IT DO?
> Deploys a skeleton project to Heroku

> [!CITE] HOW DO YOU USE IT?
> Create the required files and a Heroku application

![](https://youtu.be/Qhypx3Z2Heg)



> [!ABSTRACT] Abstract
> Contents
> 


> [!COMMAND] Requirements
> [Django3blog/02_our_first_deployment_part_1/requirements.txt at master · Code-Institute-Solutions/Django3blog (github.com)](https://github.com/Code-Institute-Solutions/Django3blog/blob/master/02_our_first_deployment_part_1/requirements.txt)
```embed
title: "requirements.txt"
image: "https://github.com/favicon.ico"
description: ""
url: "https://github.com/Code-Institute-Solutions/Django3blog/blob/master/02_our_first_deployment_part_1/requirements.txt"
```




***
### Add Video


***


> [!NOTE] Getting our skeleton project deployed to Heroku.
> 1. Firstly, create the Heroku app. Secondly, attach the database. 
> 2. Thirdly, prepare our environment  and settings.py files. 
> 3. And then, finally, get our static  and media files start on Cloudinary.
> 4. We've completed the first three steps and in  this video we'll create our Cloudinary account,  
> 5. link our project and try deployment.


***
### Add Slides

![](Pasted%20image%2020230721160638.png)

![](Pasted%20image%2020230721161207.png)



***


> [!NOTE] Benefits of Early Deployment
> 1. Firstly, we have a solid platform to build on,  
> 2. all of our main development dependencies are  installed and we know that they're working.
> 3. And secondly, a big mistake  that many students often make  
> 4. is thinking that deploying to Heroku is  as quick as deploying to Github pages. 
> 5. As a result, they often leave it to the  last minute which results in a lot of panic.  
> 6. Early deployment saves a huge amount of stress  later on


***
> . 
***

