
> [!NOTE] Title
> Contents


> [!CITE] WHAT IS IT?
> Contents

> [!CITE] WHAT DOES IT DO?
> Contents

> [!CITE] HOW DO YOU USE IT?
> Contents



> [!ABSTRACT] Abstract
> Contents
> 


> [!COMMAND] Command
> Contents


# FST I Think Therefore I Blog | Walkthrough Deployment : Heroku Config Vars

Connecting your Heroku app to your database.

---

With a new database created and the settings.py file set up to connect to it, we will need to connect our new database to Heroku.

## Process[](https://code-institute-students.github.io/deployment-docs/61-django-blog-walkthrough/django-blog-walkthrough-05-heroku-config-vars#process)

1. Go back to the Heroku dashboard open the **Settings** tab
    
    ![the settings tab selected on a heroku app](https://code-institute-students.github.io/deployment-docs/assets/heroku/settings-tab.png)
    
2. Add two config vars:
    
    - `DATABASE_URL`, and for the value, copy in your database URL from ElephantSQL, no need to add quotation marks.
        
    - `SECRET_KEY` containing your secret key.
        
    
    It should look something like this
    
    ![two config vars on heroku with the key in the left input and the value in the right input](https://code-institute-students.github.io/deployment-docs/assets/django-blog-walkthrough/blog-config-vars.png)
    

## Up Next[](https://code-institute-students.github.io/deployment-docs/61-django-blog-walkthrough/django-blog-walkthrough-05-heroku-config-vars#up-next)

So now we have created and connected a remote database, configured our settings.py file (for now…) and created some secrets, we have a few more tasks to complete before we deploy. We’ll go through these in the next video.

***
> . 
***

