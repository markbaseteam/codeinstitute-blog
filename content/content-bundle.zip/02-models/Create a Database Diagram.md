
> [!NOTE] # Creating Our Database Diagram
> Contents


> [!CITE] WHAT IS IT?
> An Entity Relationship Diagram

> [!CITE] WHAT DOES IT DO?
> Visually displays the structure of our database tables 

> [!CITE] HOW DO YOU USE IT?
> Use it as reference when building your models

![](https://youtu.be/TdXxN-4w3_s)

`Run Transcript`
https://youtu.be/TdXxN-4w3_s

> [!ABSTRACT] Abstract
> WHAT IS IT?
> 
> An Entity Relationship Diagram
> 
> WHAT DOES IT DO?
> 
> Visually displays the structure of our database tables
> 
> HOW DO YOU USE IT?
> 
> Use it as reference when building your models
> 


> [!COMMAND] Command
> Contents

![](Pasted%20image%2020230721162555.png)

![](Pasted%20image%2020230721162657.png)

![](Pasted%20image%2020230721162714.png)

***
> . 
***

