
> [!NOTE] ## Creating Our Database Models
> Contents


> [!CITE] WHAT IS IT?
> Database models

> [!CITE] WHAT DOES IT DO?
> Defines the structure of our database tables

> [!CITE] HOW DO YOU USE IT?
> Build the models from an Entity Relationship Diagram


` Run Transcript` 
![](https://youtu.be/X7cdN0SQrX0)

https://youtu.be/X7cdN0SQrX0


> [!ABSTRACT] Abstract
> WHAT IS IT?
> Database models
>  
> WHAT DOES IT DO?
> Defines the structure of our database tables
> 
> HOW DO YOU USE IT?
> Build the models from an Entity Relationship Diagram
> 


> [!COMMAND] Command
> `python mamage.py makemigrations`
> 
> `python manage.py migrate`


If you're concerned that you may have made a typing error, then you can do a dry run of your migrations before you apply them to your database. The command to do this is:

`python3 manage.py makemigrations --dry-run`

This will print out the migrations, so you can check that everything is correct before proceeding.
***
> . 
***

