
> [!NOTE] ## Building The Admin Site - part 1 & 2
> Contents


> [!CITE] WHAT IS IT?
> The Django admin panel

> [!CITE] WHAT DOES IT DO?
> Allows a superuser to administer the site

> [!CITE] HOW DO YOU USE IT?
> Log in to the /admin URL with a superuser account

![](https://youtu.be/er5IKknKxoQ)

![](https://youtu.be/JGt1p8JhPyY)

> [!ABSTRACT] Abstract
> WHAT IS IT?
> The Django admin panel
> 
> WHAT DOES IT DO?
> Allows a superuser to administer the site
> 
> HOW DO YOU USE IT?
> Log in to the /admin URL with a superuser account
> 


> [!COMMAND] Command
> Contents

```embed
title: "Django"
image: "https://static.djangoproject.com/img/logos/django-logo-negative.1d528e2cb5fb.png"
description: "The web framework for perfectionists with deadlines."
url: "https://docs.djangoproject.com/en/3.2/topics/http/urls/#how-django-processes-a-request"
```
`Switch to 4.2 for latest`

```embed
title: "Django"
image: "https://static.djangoproject.com/img/logos/django-logo-negative.1d528e2cb5fb.png"
description: "The web framework for perfectionists with deadlines."
url: "https://docs.djangoproject.com/en/3.1/ref/contrib/admin/#django.contrib.admin.ModelAdmin.list_display"
```
`Switch to 4.2 for latest`

```embed
title: "Django"
image: "https://static.djangoproject.com/img/logos/django-logo-negative.1d528e2cb5fb.png"
description: "The web framework for perfectionists with deadlines."
url: "https://docs.djangoproject.com/en/3.1/ref/contrib/admin/#django.contrib.admin.ModelAdmin.search_fields"
```
`Switch to 4.2 for latest`

```embed
title: "Summernote - Super Simple WYSIWYG editor"
image: "https://summernote.org/img/icons/1200x630.png"
description: "Super Simple WYSIWYG Editor on Bootstrap Summernote is a JavaScript library that helps you create WYSIWYG editors online."
url: "https://summernote.org/"
```

```embed
title: ""
image: "https://github.com/Code-Institute-Solutions/Django3blog/tree/master/05_building_the_admin_site"
description: ""
url: "https://github.com/Code-Institute-Solutions/Django3blog/tree/master/05_building_the_admin_site"
```



***
> . 
***

