
> [!NOTE] ## View Creation Checklist
> Contents


> [!CITE] WHAT IS IT?
> Our first views & checklist

> [!CITE] WHAT DOES IT DO?
> Allows us to view our blog post list

> [!CITE] HOW DO YOU USE IT?
> Follow the three step process to creating new views

![](https://youtu.be/LP-glKOWpi8)

`Transcript URL`
https://youtu.be/LP-glKOWpi8

![](https://youtu.be/62vzUj7OmgM)

`Transcript URL`
https://youtu.be/62vzUj7OmgM

> [!ABSTRACT] Abstract
> WHAT IS IT?
> Our first views 
> 
> WHAT DOES IT DO?
> Allows us to view our blog post list
> 
> HOW DO YOU USE IT?
> Follow the three step process to creating new views
> 

> [!COMMAND] Command
> Contents

![](Pasted%20image%2020230721164904.png)

![](Pasted%20image%2020230721164932.png)

![](Pasted%20image%2020230721164956.png)

![](Pasted%20image%2020230721165038.png)

```embed
title: "GitHub - Code-Institute-Solutions/django-blog-starter-files: HTML templates and CSS file for the Django blog"
image: "https://opengraph.githubassets.com/b02818fbafdbb8b848a0540894e0844888421100ef9da3e115f5264a8f4fbc2d/Code-Institute-Solutions/django-blog-starter-files"
description: "HTML templates and CSS file for the Django blog. Contribute to Code-Institute-Solutions/django-blog-starter-files development by creating an account on GitHub."
url: "https://github.com/Code-Institute-Solutions/django-blog-starter-files"
```

```embed
title: "Django"
image: "https://static.djangoproject.com/img/logos/django-logo-negative.1d528e2cb5fb.png"
description: "The web framework for perfectionists with deadlines."
url: "https://docs.djangoproject.com/en/3.2/topics/class-based-views/generic-display/"
```

```embed
title: ""
image: "https://github.com/Code-Institute-Solutions/Django3blog/tree/master/06_creating_our_first_view"
description: ""
url: "https://github.com/Code-Institute-Solutions/Django3blog/tree/master/06_creating_our_first_view"
```


***
> . 
***

