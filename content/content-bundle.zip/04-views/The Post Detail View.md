
> [!NOTE] ## The Post Detail View
> - Assumed a Multi Page Architecture, with page reload and not a single page architecture with in place updates


> [!CITE] WHAT IS IT?
> The post detail view

> [!CITE] WHAT DOES IT DO?
> Allows us to view the content of our blog post

> [!CITE] HOW DO YOU USE IT?
> Follow the three step process to creating new views


![](https://youtu.be/gUHXWF0M0c8)

`Transcrupt URL`
https://youtu.be/gUHXWF0M0c8 

![](https://youtu.be/9bFzeSlxPbs)

`Transcript URL`
https://youtu.be/9bFzeSlxPbs

> [!ABSTRACT] Abstract
> WHAT IS IT?
> The post detail view
> 
> WHAT DOES IT DO?
> Allows us to view the content of our blog post
> 
> HOW DO YOU USE IT?
> Follow the three step process to creating new views
> 


> [!COMMAND] Command
> Contents


***
> . 
***

