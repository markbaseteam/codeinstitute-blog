---

kanban-plugin: basic

---

## 01 Creating the Project

- [x] [Creating The Django Project Checklist](Creating%20The%20Django%20Project%20Checklist.md)
- [x] [Creating The Empty Django Project](Creating%20The%20Empty%20Django%20Project.md)
- [x] [Create a Heroku App](Create%20a%20Heroku%20App.md)
- [x] [Create a database](Create%20a%20database.md)
- [x] [Create a ` .env` file](Create%20a%20`%20.env`%20file.md)
- [x] [Manage `settings.py` ](Manage%20`settings.py`.md)


## 02 First Deployment

- [x] [Heroku Config File](Heroku%20Config%20File.md)
- [x] [Deployment](Deployment.md)


## 03 Build the Models

- [x] [Create a Database Diagram](Create%20a%20Database%20Diagram.md)
- [x] [Create a DB Model](Create%20a%20DB%20Model.md)


## 04 Build the Admin

- [x] [Build an Admin Site](Build%20an%20Admin%20Site.md)


## 05 Create First View

- [x] [Views Creation Checklist](Views%20Creation%20Checklist.md)
- [x] [Create our First View](Create%20our%20First%20View.md)


## 07 Add Post Detail

- [x] [The Post Detail View](The%20Post%20Detail%20View.md)


## 08 Authorisation

- [x] [Authorisation](Authorisation.md)


## 09 Commenting

- [x] [Commenting Like](Commenting%20Like.md)


## 10 Likes

- [x] [Likes](Likes.md)


## 12 Messages

- [x] [Messages](Messages.md)


## 13 Final Deploy

- [x] [Final Deployment](Final%20Deployment.md)


## Done

**Complete**




%% kanban:settings
```
{"kanban-plugin":"basic"}
```
%%