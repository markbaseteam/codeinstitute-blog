PP4 MC Blog
- [x] Repo Cloned
- [x] Repo Trimmed of Image/CDE
- [x] Django Steps for a Deploy unit
  - [ ] Delta
    - [ ] Start with 3.2.3 or 4.2.3
    - [ ]  Not LTS 3.2 => all to latest
    - [ ] Psycgopg2-binary 2.8.6 - ≥2.9.6
    - [ ] runtime.txt 3.10.6=>3.11.3
  - [ ] Done for @latest
    - [ ] Python: 3.11.3 => runtime.txt
    - [ ] Install Django => 4.2
      - [ ] Doc: 4.2
      - [ ] GH Dependabot bump => 4.2
      - [ ] Verify from Shell
      - [ ] 
    - [ ] IDE & Packages: requirements.txt
    - [ ] `manage.py`  
  - [ ]  ToDo
    - [ ] Install Requirements for as-is
      - [ ] `pip install -r requirements.txt` 
    - [ ]   Database: ElephantSQL
      - [ ]  New Instance
      - [ ]  Instance details
      - [ ]  PW Mgr 
    - [ ]  Heroku
      - [ ] Web
      - [ ] CLI


# Deploy the LTS 3.3.2 Django (As-IS)

1. [x] Run `pip install -r requirements.txt`
	1. [x] Issue: pyscopg2-binary 2.8.6 => Installed psycopg2-binary
	2. [x] Via PowerShell
2. [x] Install Posgress\15 and check for pg_config instiil
	1. [x] Remove from WinGet package manager
3. [x] Detach from Source Git 
	1. [x] No pushing changes to https://github.com/Code-Institute-Solutions/PP4_masterclass/tree/main
	2. [x] Instead: Unlink by deleting .git folder
4. Attach to Heroku (via CLI) to an app
	1. `heroku login`
	2. Opens Browser to  to https://cli-auth.heroku.com/auth/cli/browser/**
	3. Follow the 2FA flow 
	4. `git init`
	5. Create a heroku remote: `heroku git:remote -a xgitaccess`

`pip install -r requirements.txt`
```
Installing collected packages: pytz, dj-database-url, whitenoise, urllib3, sqlparse, six, PyJWT, pycparser, psycopg2-binary, oauthlib, idna, gunicorn, django-crispy-forms, defusedxml, charset-normalizer, certifi, asgiref, requests, python3-openid, Django, cloudinary, cffi, requests-oauthlib, django-summernote, dj3-cloudinary-storage, cryptography, django-allauth

Successfully installed Django-3.2.3 PyJWT-2.1.0 asgiref-3.3.4 certifi-2023.7.22 cffi-1.15.1 charset-normalizer-3.2.0 cloudinary-1.25.0 cryptography-3.4.8 defusedxml-0.7.1 dj-database-url-0.5.0 dj3-cloudinary-storage-0.0.5 django-allauth-0.44.0 django-crispy-forms-1.11.2 django-summernote-0.8.11.6 gunicorn-20.1.0 idna-3.4 oauthlib-3.1.1 psycopg2-binary-2.9.6 pycparser-2.21 python3-openid-3.2.0 pytz-2021.1 requests-2.31.0 requests-oauthlib-1.3.0 six-1.16.0 sqlparse-0.4.1 urllib3-2.0.4 whitenoise-5.3.0
```

`pip install -r requirements-dev-txt`
```
Installing collected packages: distlib, wrapt, typing-extensions, tomlkit, toml, smmap, ruff, ruamel.yaml.clib, pyyaml, platformdirs, packaging, nodeenv, natsort, mypy-extensions, mccabe, lazy-object-proxy, isort, identify, handy-archives, filelock, dill, colorama, cfgv, attrs, virtualenv, ruamel.yaml, pre-commit-ci-config, mypy, gitdb, domdf-python-tools, click, astroid, pylint, pre-commit-hooks, pre-commit, GitPython, dom-toml, dist-meta, apeye-core, apeye, shippinglabel, pyproject-parser, pre-commit-update

Successfully installed GitPython-3.1.32 apeye-1.4.0 apeye-core-1.1.4 astroid-2.15.6 attrs-23.1.0 cfgv-3.3.1 click-8.1.6 colorama-0.4.6 dill-0.3.6 dist-meta-0.8.0 distlib-0.3.7 dom-toml-0.6.1 domdf-python-tools-3.6.1 filelock-3.12.2 gitdb-4.0.10 handy-archives-0.1.4 identify-2.5.25 isort-5.12.0 lazy-object-proxy-1.9.0 mccabe-0.7.0 mypy-1.4.1 mypy-extensions-1.0.0 natsort-8.4.0 nodeenv-1.8.0 packaging-23.1 platformdirs-3.9.1 pre-commit-3.3.3 pre-commit-ci-config-1.5.1 pre-commit-hooks-4.4.0 pre-commit-update-0.0.8 pylint-2.17.4 pyproject-parser-0.8.0 pyyaml-6.0.1 ruamel.yaml-0.17.32 ruamel.yaml.clib-0.2.7 ruff-0.0.280 shippinglabel-1.5.0 smmap-5.0.0 toml-0.10.2 tomlkit-0.11.8 typing-extensions-4.7.1 virtualenv-20.24.1 wrapt-1.15.0
```

5. Configure `.gitconfig` for line endings into Heroku’s Unix/Linux eco systems
	1. git config --global core.autocrlf false
	2. git config --global core.eol lf
	3. .
6. If pycharm commit error in updating changes: dubious ownership in repository
	1. then `git config --global --add safe.directory /path/to/repository`
7. Git 1st commit 
	1.  `git add .`
	2. `git commit -am “message”`
	3. `git push heroku main`
8. [GPG Signing ]([walkthrough](walkthrough.md#^3lbnq0))
	1. [x] Remove  - Disable GPG
	2. [ ] ~~Configure~~ 
	3. => Git commit works for 1st run
9.  Configure Heroku Environmental Vars
10. 
11.  1st Git Pushing 

#### 1st Git Push - Deploy / Integration Test Fail
- 1st run, no env configs, as-is

```
 PP4_masterclass  git pull heroku master
fatal: couldn't find remote ref master
 PP4_masterclass  git push heroku main
Enumerating objects: 206, done.
Counting objects: 100% (206/206), done.
Delta compression using up to 12 threads
Compressing objects: 100% (192/192), done.
Writing objects: 100% (206/206), 412.00 KiB | 5.35 MiB/s, done.
Total 206 (delta 35), reused 0 (delta 0), pack-reused 0
remote: Resolving deltas: 100% (35/35), done.
remote: Updated 176 paths from e6c90a8
remote: Compressing source files... done.
remote: Building source:
remote: 
remote: -----> Building on the Heroku-22 stack
remote: -----> Determining which buildpack to use for this app
remote: -----> Python app detected
remote: -----> Using Python version specified in runtime.txt
remote:  !     
remote:  !     A Python security update is available! Upgrade as soon as possible to: python-3.11.4
remote:  !     See: https://devcenter.heroku.com/articles/python-runtimes
remote:  !
remote: -----> Installing python-3.11.3
remote: -----> Installing pip 23.1.2, setuptools 67.8.0 and wheel 0.40.0
remote: -----> Installing SQLite3
remote: -----> Installing requirements with pip

remote:        Successfully built cloudinary django-allauth django-summernote
remote:        Installing collected packages: pytz, dj-database-url, whitenoise, urllib3, sqlparse, six, PyJWT, pycparser, psycopg2-binary, oauthlib, idna, gunicorn, django-crispy-forms, defusedxml, charset-normalizer, certifi, asgiref, requests, python3-openid, Django, cloudinary, cffi, requests-oauthlib, django-summernote, dj3-cloudinary-storage, cryptography, django-allauth

remote:        Successfully installed Django-3.2.3 PyJWT-2.1.0 asgiref-3.3.4 certifi-2023.7.22 cffi-1.15.1 charset-normalizer-3.2.0 cloudinary-1.25.0 cryptography-3.4.8 defusedxml-0.7.1 dj-database-url-0.5.0 dj3-cloudinary-storage-0.0.5 django-allauth-0.44.0 django-crispy-forms-1.11.2 django-summernote-0.8.11.6 gunicorn-20.1.0 idna-3.4 oauthlib-3.1.1 psycopg2-binary-2.9.6 pycparser-2.21 python3-openid-3.2.0 pytz-2021.1 requests-2.31.0 requests-oauthlib-1.3.0 six-1.16.0 sqlparse-0.4.1 urllib3-2.0.4 whitenoise-5.3.0

remote: -----> $ python manage.py collectstatic --noinput

remote:        Traceback (most recent call last):
remote:          File "/tmp/build_2dee605a/manage.py", line 22, in <module>
remote:            main()
remote:          File "/tmp/build_2dee605a/manage.py", line 18, in main
remote:            execute_from_command_line(sys.argv)
remote:          File "/app/.heroku/python/lib/python3.11/site-packages/django/core/management/__init__.py", line 419, in execute_from_command_line
remote:            utility.execute()
remote:          File "/app/.heroku/python/lib/python3.11/site-packages/django/core/management/__init__.py", line 363, in execute
remote:            settings.INSTALLED_APPS
remote:          File "/app/.heroku/python/lib/python3.11/site-packages/django/conf/__init__.py", line 82, in __getattr__
remote:            self._setup(name)
remote:          File "/app/.heroku/python/lib/python3.11/site-packages/django/conf/__init__.py", line 69, in _setup
remote:            self._wrapped = Settings(settings_module)
remote:                            ^^^^^^^^^^^^^^^^^^^^^^^^^
remote:          File "/app/.heroku/python/lib/python3.11/site-packages/django/conf/__init__.py", line 170, in __init__
remote:            mod = importlib.import_module(self.SETTINGS_MODULE)
remote:                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
remote:          File "/app/.heroku/python/lib/python3.11/importlib/__init__.py", line 126, in import_module
remote:            return _bootstrap._gcd_import(name[level:], package, level)
remote:                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
remote:          File "<frozen importlib._bootstrap>", line 1206, in _gcd_import
remote:          File "<frozen importlib._bootstrap>", line 1178, in _find_and_load
remote:          File "<frozen importlib._bootstrap>", line 1149, in _find_and_load_unlocked
remote:          File "<frozen importlib._bootstrap>", line 690, in _load_unlocked
remote:          File "<frozen importlib._bootstrap_external>", line 940, in exec_module
remote:          File "<frozen importlib._bootstrap>", line 241, in _call_with_frames_removed
remote:          File "/tmp/build_2dee605a/codestar/settings.py", line 116, in <module>
remote:            'default': dj_database_url.parse(os.environ.get("DATABASE_URL"))
remote:                       ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
remote:          File "/app/.heroku/python/lib/python3.11/site-packages/dj_database_url.py", line 80, in parse
remote:            if '?' in path and not url.query:
remote:               ^^^^^^^^^^^

remote:        TypeError: a bytes-like object is required, not 'str'
remote: 

remote:  !     Error while running '$ python manage.py collectstatic --noinput'.
remote:        See traceback above for details.
remote:
remote:        You may need to update application code to resolve this error.
remote:        Or, you can disable collectstatic for this application:
remote:
remote:           $ heroku config:set DISABLE_COLLECTSTATIC=1
remote:
remote:        https://devcenter.heroku.com/articles/django-assets
remote:  !     Push rejected, failed to compile Python app.
remote: 
remote:  !     Push failed
remote: Verifying deploy...
remote:
remote: !       Push rejected to xgitaccess.
remote:
To https://git.heroku.com/xgitaccess.git
 ! [remote rejected] main -> main (pre-receive hook declined)
error: failed to push some refs to 'https://git.heroku.com/xgitaccess.git'

```

