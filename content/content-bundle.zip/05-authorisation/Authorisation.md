
> [!NOTE] ## Authorisation - AllAuth
> Contents
- [Welcome to django-allauth! — django-allauth 0.43.0 documentation](https://django-allauth.readthedocs.io/en/latest/)




> [!CITE] WHAT IS IT?
> Django AllAuth 

> [!CITE] WHAT DOES IT DO?
> Allows us to easily add authentication to our project

> [!CITE] HOW DO YOU USE IT?
> Install and configure the AllAuth library 


# Important!

## Email authentication

To prevent 500 errors during login and registration, you need to make a one line addition to your settings.py file:

`ACCOUNT_EMAIL_VERIFICATION = 'none'`  
  

After this, both login and registration should work without errors regardless of whether you use an email address to sign in/up.

![](https://youtu.be/HlocBbrss04)

![](https://youtu.be/IYlhc4c64U4)

> [!ABSTRACT] Abstract
> WHAT IS IT?
> Django AllAuth 
> 
> WHAT DOES IT DO?
> Allows us to easily add authentication to our project
> 
> HOW DO YOU USE IT?
> Install and configure the AllAuth library
> 


> [!COMMAND] Command
> Contents

[Completed Template Files (github.com)](https://github.com/Code-Institute-Solutions/django-blog-starter-files/tree/master/templates/account)
```embed
title: "account"
image: "https://github.com/favicon.ico"
description: ""
url: "https://github.com/Code-Institute-Solutions/django-blog-starter-files/tree/master/templates/account"
```

[Django AllAuth Documentation (django-allauth.readthedocs.io)](https://django-allauth.readthedocs.io/en/latest/)
```embed
title: "Welcome to django-allauth! — django-allauth 0.43.0 documentation"
image: "https://github.com/pennersr/django-allauth/actions/workflows/ci.yml/badge.svg"
description: "Integrated set of Django applications addressing authentication, registration, account management as well as 3rd party (social) account authentication."
url: "https://django-allauth.readthedocs.io/en/latest/"
```

[View Source Code (github.com)](https://github.com/Code-Institute-Solutions/Django3blog/tree/master/08_authorisation)
```embed
title: "Fetching"

description: "Fetching https://github.com/Code-Institute-Solutions/Django3blog/tree/master/08_authorisation"
url: "https://github.com/Code-Institute-Solutions/Django3blog/tree/master/08_authorisation"
```


### AllAuth 

#### Settings 

```python

#. Specify the context processors as follows:
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                # Already defined Django-related contexts here

                # `allauth` needs this from django
                'django.template.context_processors.request',
            ],
        },
    },
]

AUTHENTICATION_BACKENDS = [
    ...
    # Needed to login by username in Django admin, regardless of `allauth`
    'django.contrib.auth.backends.ModelBackend',

    # `allauth` specific authentication methods, such as login by e-mail
    'allauth.account.auth_backends.AuthenticationBackend',
    ...
]

INSTALLED_APPS = [
...
# The following apps are required:
'django.contrib.auth',
'django.contrib.messages',
'django.contrib.sites',

'allauth',
'allauth.account',
'allauth.socialaccount',
'allauth.socialaccount.providers.github',
...
]

SITE_ID = 1

# Provider specific settings
SOCIALACCOUNT_PROVIDERS = {
    'google': {
        # For each OAuth based provider, either add a ``SocialApp``
        # (``socialaccount`` app) containing the required client
        # credentials, or list them here:
        'APP': {
            'client_id': '123',
            'secret': '456',
            'key': ''
        }
    }
}
```

#### Urls.py

```
urlpatterns = [
...
path('accounts/', include('allauth.urls')),
...
]`
```

### Configuration

[Configuration — django-allauth 0.43.0 documentation](https://django-allauth.readthedocs.io/en/latest/configuration.html)


***
> . 
***

