
> [!NOTE] ## [Messages](https://docs.djangoproject.com/en/3.2/ref/contrib/messages/#using-messages-in-views-and-templates)
> - Bootstrap 
> - Messages in Django


- [Using messages in views and templates](https://docs.djangoproject.com/en/3.2/ref/contrib/messages/#using-messages-in-views-and-templates)
    - [Adding a message](https://docs.djangoproject.com/en/3.2/ref/contrib/messages/#adding-a-message)
    - [Displaying messages](https://docs.djangoproject.com/en/3.2/ref/contrib/messages/#displaying-messages)
    - [The `Message` class](https://docs.djangoproject.com/en/3.2/ref/contrib/messages/#the-message-class)
    - [Creating custom message levels](https://docs.djangoproject.com/en/3.2/ref/contrib/messages/#creating-custom-message-levels)
    - [Changing the minimum recorded level per-request](https://docs.djangoproject.com/en/3.2/ref/contrib/messages/#changing-the-minimum-recorded-level-per-request)
    - [Adding extra message tags](https://docs.djangoproject.com/en/3.2/ref/contrib/messages/#adding-extra-message-tags)
    - [Failing silently when the message framework is disabled](https://docs.djangoproject.com/en/3.2/ref/contrib/messages/#failing-silently-when-the-message-framework-is-disabled)
    - [Adding messages in class-based views](https://docs.djangoproject.com/en/3.2/ref/contrib/messages/#adding-messages-in-class-based-views)
- [Expiration of messages](https://docs.djangoproject.com/en/3.2/ref/contrib/messages/#expiration-of-messages)
- [Behavior of parallel requests](https://docs.djangoproject.com/en/3.2/ref/contrib/messages/#behavior-of-parallel-requests)
- [Settings](https://docs.djangoproject.com/en/3.2/ref/contrib/messages/#settings)

> [!CITE] WHAT IS IT?
> Messages

> [!CITE] WHAT DOES IT DO?
> Contents

> [!CITE] HOW DO YOU USE IT?
> Add the message tags and some custom JavaScript

![](https://youtu.be/kCnfxIUKZoY)

> [!ABSTRACT] Abstract
> WHAT IS IT?
> Messages
>
>WHAT DOES IT DO?
> Allows us to provide flash messages to our user
>
>  HOW DO YOU USE IT?
> Add the message tags and some custom JavaScript
> 

![](Pasted%20image%2020230721232046.png)

![](Pasted%20image%2020230721232118.png)

![](Pasted%20image%2020230721232245.png)



> [!COMMAND] Command
> Contents

[Bootstrap Alert Documentation (getbootstrap.com)](https://getbootstrap.com/docs/5.0/components/alerts/)
```embed
title: "Fetching"

description: "Fetching https://getbootstrap.com/docs/5.0/components/alerts/"
url: "https://getbootstrap.com/docs/5.0/components/alerts/"
```

[Using Messages in Django (djangoproject.com)](h
```embed
title: "Django"
image: "https://static.djangoproject.com/img/logos/django-logo-negative.1d528e2cb5fb.png"
description: "The web framework for perfectionists with deadlines."
url: "https://docs.djangoproject.com/en/3.2/ref/contrib/messages/#using-messages-in-views-and-templates"
```


***
> . 
***

