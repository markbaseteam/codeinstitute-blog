
> [!NOTE] ## Final Deployment
> - [CORS]() 
>    - [Cross-Origin Resource Sharing (CORS) - HTTP | MDN (mozilla.org)](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS))
>    

## In this article

- [What requests use CORS?](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS#what_requests_use_cors)
- [Functional overview](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS#functional_overview)
- [Examples of access control scenarios](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS#examples_of_access_control_scenarios)
- [The HTTP response headers](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS#the_http_response_headers)
	- [Access-Control-Allow-Origin](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS#access-control-allow-origin)
	- [Access-Control-Expose-Headers](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS#access-control-expose-headers)
	- [Access-Control-Max-Age](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS#access-control-max-age)
	- [Access-Control-Allow-Credentials](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS#access-control-allow-credentials)
	- [Access-Control-Allow-Methods](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS#access-control-allow-methods)
	- [Access-Control-Allow-Headers](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS#access-control-allow-headers)
- [The HTTP request headers](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS#the_http_request_headers)
	-  [Origin](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS#origin)
	- [Access-Control-Request-Method](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS#access-control-request-method)
	- [Access-Control-Request-Headers](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS#access-control-request-headers)
- [Specifications](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS#specifications)
- [Browser compatibility](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS#browser_compatibility)
- [See also](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS#see_also)

> [!CITE] WHAT IS IT?
> Contents

> [!CITE] WHAT DOES IT DO?
> Contents

> [!CITE] HOW DO YOU USE IT?
> Contents



> [!ABSTRACT] Abstract
> Contents
> 


> [!COMMAND] Command
> Contents

[What is CORS?? (mozilla.org)](https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS)
```embed
title: "Cross-Origin Resource Sharing (CORS) - HTTP | MDN"
image: "https://developer.mozilla.org/mdn-social-share.cd6c4a5a.png"
description: "Cross-Origin Resource Sharing (CORS) is an HTTP-header based mechanism that allows a server to indicate any origins (domain, scheme, or port) other than its own from which a browser should permit loading resources. CORS also relies on a mechanism by which browsers make a “preflight” request to the s…"
url: "https://developer.mozilla.org/en-US/docs/Web/HTTP/CORS"
```

[View Source Code (github.com)](https://github.com/Code-Institute-Solutions/Django3blog/tree/master/12_final_deployment)
```embed
title: "12_final_deployment"
image: "https://github.com/favicon.ico"
description: ""
url: "https://github.com/Code-Institute-Solutions/Django3blog/tree/master/12_final_deployment"
```

[Configuring Social Sign-on (django-allauth.readthedocs.io)](https://django-allauth.readthedocs.io/en/latest/providers.html#google)
```embed
title: "Providers — django-allauth 0.43.0 documentation"
image: "https://django-allauth.readthedocs.io/favicon.ico"
description: "Most providers require you to sign up for a so called API client or app, containing a client ID and API secret. You must add a SocialApp record per provider via the Django admin containing these app credentials."
url: "https://django-allauth.readthedocs.io/en/latest/providers.html#google"
```


***
> . 
***

